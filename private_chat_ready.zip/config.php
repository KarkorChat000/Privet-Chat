<?php
declare(strict_types=1);
const DB_FILE = __DIR__ . '/data/chat.sqlite';
const POLL_LIMIT = 80;
if (!is_dir(__DIR__.'/data')) mkdir(__DIR__.'/data',0755,true);
function db(): PDO {
    static $pdo;
    if (!$pdo) {
        $pdo=new PDO('sqlite:'.DB_FILE,null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
        $pdo->exec("PRAGMA journal_mode=WAL;");
        $pdo->exec("CREATE TABLE IF NOT EXISTS rooms(code TEXT PRIMARY KEY, created_at INTEGER NOT NULL)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, room TEXT NOT NULL, name TEXT NOT NULL, body TEXT NOT NULL, created_at INTEGER NOT NULL)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_messages_room_id ON messages(room,id)");
    }
    return $pdo;
}
function room_exists(string $code): bool {
    $s=db()->prepare("SELECT 1 FROM rooms WHERE code=?"); $s->execute([$code]); return (bool)$s->fetchColumn();
}
function create_room(string $code): void {
    $s=db()->prepare("INSERT OR IGNORE INTO rooms(code,created_at) VALUES(?,?)"); $s->execute([$code,time()]);
}
function clean_text(string $s,int $max): string {
    $s=trim($s); if(mb_strlen($s)>$max) $s=mb_substr($s,0,$max); return $s;
}
function json_out(array $data): never {
    header('Content-Type: application/json; charset=utf-8'); echo json_encode($data,JSON_UNESCAPED_UNICODE); exit;
}
